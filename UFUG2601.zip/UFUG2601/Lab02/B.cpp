#include <bits/stdc++.h>

using namespace std;

typedef long long LL;
int main() {
    LL a, b; scanf("%lld%lld", &a, &b);
    printf("%lld\n", a + b);
    return 0;
}